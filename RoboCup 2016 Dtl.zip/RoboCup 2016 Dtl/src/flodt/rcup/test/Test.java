package flodt.rcup.test;

public class Test {
	/**
	 * Test method for experiments.
	 * @param args
	 */
	public static void main(String[] args) {
		
	}

}
