package flodt.rcup.libs;

public class SensorPort {
	public static final String ONE = "S1";
	public static final String TWO = "S2";
	public static final String THREE = "S3";
	public static final String FOUR = "S4";
}
